#include "Idle.h"

void Idle::run(){
	while (1) {}
}

